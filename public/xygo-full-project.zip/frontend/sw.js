const CACHE = 'xygo-v5';
const ASSETS = ['/', '/index.html', '/manifest.json', '/logo.png', '/icon-192.png', '/icon-512.png'];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  if (
    url.hostname.includes('duckdns.org') ||
    url.pathname.includes('/socket.io') ||
    url.pathname.includes('/api/') ||
    e.request.method !== 'GET'
  ) return; // laisser passer sans interception

  e.respondWith(
    caches.match(e.request).then(cached => {
      if (cached) return cached;
      // Fetch + mise en cache (corriger le bug clone)
      return fetch(e.request).then(response => {
        if (!response || response.status !== 200 || response.type === 'opaque') {
          return response;
        }
        // Cloner AVANT de lire
        const toCache = response.clone();
        caches.open(CACHE).then(c => c.put(e.request, toCache));
        return response;
      });
    }).catch(() => caches.match('/index.html'))
  );
});

// ── Push reçue ────────────────────────────────────────────────────────────────
self.addEventListener('push', e => {
  if (!e.data) return;
  let data;
  try { data = e.data.json(); } catch(_) { data = { title:'XyGo', body: e.data.text() }; }

  e.waitUntil(
    self.registration.showNotification(data.title || 'XyGo', {
      body: data.body || 'Nouveau message',
      icon: '/icon-192.png',
      badge: '/icon-72.png',
      vibrate: [200, 100, 200],
      tag: data.tag || 'xygo',
      renotify: true,
      data: data.data || {}
    })
  );
});

// ── Clic sur notification ─────────────────────────────────────────────────────
self.addEventListener('notificationclick', e => {
  e.notification.close();
  e.waitUntil(
    clients.matchAll({ type:'window', includeUncontrolled:true }).then(list => {
      for (const client of list) {
        if ('focus' in client) {
          client.postMessage({ type:'OPEN_CHAT', fromId: e.notification.data?.fromId });
          return client.focus();
        }
      }
      if (clients.openWindow) return clients.openWindow('/');
    })
  );
});
