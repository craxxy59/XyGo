require('dotenv').config();
const webpush    = require('web-push');
const express      = require('express');
const http         = require('http');
const { Server }   = require('socket.io');
const session      = require('express-session');
const cookieParser = require('cookie-parser');
const bcrypt       = require('bcrypt');
const Database     = require('better-sqlite3');
const cors         = require('cors');
const crypto       = require('crypto');
const https        = require('https');
const path         = require('path');

const app    = express();
const server = http.createServer(app);

// ── Constantes ────────────────────────────────────────────────────────────────
const ADMIN_LOGIN   = 'Craxxy5909';
const ALLOWED_ORIGINS = process.env.ALLOWED_ORIGINS
  ? process.env.ALLOWED_ORIGINS.split(',')
  : ['*'];
const VAPID_PUBLIC  = process.env.VAPID_PUBLIC  || 'BMxjydPmrJd5aEaQvNInfB1l-nZBMB8u-TShVZlE5sgdfMrYTriAZ98OC-PIywFWl2Lodb1YPjW4AaMApK9qSXU';
const VAPID_PRIVATE = process.env.VAPID_PRIVATE || 'RLGfjGOuvt_b-fIMXUWWPMajA_iyfclfV-7V0KpXGkI';
const VAPID_SUBJECT = process.env.VAPID_SUBJECT || 'mailto:admin@xygo.app';

// Configurer web-push avec les clés VAPID
webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC, VAPID_PRIVATE);

// ── Base de données ───────────────────────────────────────────────────────────
const db = new Database('messenger.db');
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    login        TEXT UNIQUE NOT NULL,
    display_name TEXT UNIQUE NOT NULL,
    password     TEXT NOT NULL,
    bio          TEXT DEFAULT '',
    role         TEXT DEFAULT 'user',
    banned       INTEGER DEFAULT 0,
    ban_reason   TEXT DEFAULT '',
    banned_until TEXT DEFAULT NULL,
    grade        TEXT DEFAULT NULL,
    online       INTEGER DEFAULT 0,
    created_at   TEXT DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS messages (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    sender_id   INTEGER NOT NULL,
    receiver_id INTEGER NOT NULL,
    content     TEXT NOT NULL,
    reply_to    INTEGER DEFAULT NULL,
    read        INTEGER DEFAULT 0,
    deleted     INTEGER DEFAULT 0,
    edited      INTEGER DEFAULT 0,
    created_at  TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (sender_id)   REFERENCES users(id),
    FOREIGN KEY (receiver_id) REFERENCES users(id)
  );
  CREATE TABLE IF NOT EXISTS reactions (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id INTEGER NOT NULL,
    user_id    INTEGER NOT NULL,
    emoji      TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now')),
    UNIQUE(message_id, user_id, emoji),
    FOREIGN KEY (message_id) REFERENCES messages(id),
    FOREIGN KEY (user_id)    REFERENCES users(id)
  );
  CREATE TABLE IF NOT EXISTS tokens (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    token      TEXT UNIQUE NOT NULL,
    expires_at TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(id)
  );
  CREATE TABLE IF NOT EXISTS push_subscriptions (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    endpoint   TEXT UNIQUE NOT NULL,
    p256dh     TEXT NOT NULL,
    auth       TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(id)
  );
  CREATE TABLE IF NOT EXISTS audit_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_id   INTEGER NOT NULL,
    action     TEXT NOT NULL,
    target     TEXT DEFAULT '',
    detail     TEXT DEFAULT '',
    created_at TEXT DEFAULT (datetime('now'))
  );
`);

// Migrations colonnes manquantes
['role TEXT DEFAULT \'user\'','banned INTEGER DEFAULT 0','ban_reason TEXT DEFAULT \'\'',
 'banned_until TEXT DEFAULT NULL','deleted INTEGER DEFAULT 0','edited INTEGER DEFAULT 0',
 'reply_to INTEGER DEFAULT NULL'].forEach(col => {
  const [name] = col.split(' ');
  const table = col.includes('ban') || col.includes('role') || col.includes('online') ? 'users' : 'messages';
  try { db.exec(`ALTER TABLE users ADD COLUMN ${col}`); } catch(_){}
  try { db.exec(`ALTER TABLE messages ADD COLUMN ${col}`); } catch(_){}
});
try { db.exec("ALTER TABLE users ADD COLUMN grade TEXT DEFAULT NULL"); } catch(_){}
try { db.exec(`UPDATE users SET login=username, display_name=username WHERE login IS NULL OR login=''`); } catch(_){}

// Admin role
const _admin = db.prepare('SELECT id FROM users WHERE login=?').get(ADMIN_LOGIN);
if (_admin) db.prepare("UPDATE users SET role='admin' WHERE id=?").run(_admin.id);

// ── Token Auth ────────────────────────────────────────────────────────────────
function createUserToken(userId) {
  const token   = crypto.randomBytes(32).toString('hex');
  const expires = new Date(Date.now() + 7*24*60*60*1000).toISOString();
  try { db.prepare('DELETE FROM tokens WHERE user_id=?').run(userId); } catch(_){}
  db.prepare('INSERT INTO tokens (user_id,token,expires_at) VALUES (?,?,?)').run(userId, token, expires);
  return token;
}
function getUserFromToken(token) {
  if (!token) return null;
  try {
    const row = db.prepare("SELECT user_id FROM tokens WHERE token=? AND expires_at>datetime('now')").get(token);
    return row ? db.prepare('SELECT * FROM users WHERE id=?').get(row.user_id) : null;
  } catch(_) { return null; }
}
setInterval(() => {
  try { db.prepare("DELETE FROM tokens WHERE expires_at<=datetime('now')").run(); } catch(_){}
}, 60*60*1000);

// ── CORS ──────────────────────────────────────────────────────────────────────
const corsOptions = {
  origin: (origin, cb) => {
    if (!origin || ALLOWED_ORIGINS.includes('*') || ALLOWED_ORIGINS.includes(origin)) return cb(null, true);
    cb(new Error('CORS: ' + origin));
  },
  credentials: true,
  methods: ['GET','POST','PUT','DELETE','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization','X-Requested-With'],
};
app.use(cors(corsOptions));
app.options('*', cors(corsOptions));
app.set('trust proxy', 1);

const io = new Server(server, {
  cors: {
    origin: (origin, cb) => {
      if (!origin || ALLOWED_ORIGINS.includes('*') || ALLOWED_ORIGINS.includes(origin)) return cb(null, true);
      cb(new Error('CORS Socket'));
    },
    credentials: true,
  }
});

// ── Session ───────────────────────────────────────────────────────────────────
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

const sessionMiddleware = session({
  secret: process.env.SESSION_SECRET || 'nexus_craxxy_secret_2024!',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 7*24*60*60*1000, sameSite: 'none', secure: true, httpOnly: true }
});
app.use(sessionMiddleware);

// Socket.io token middleware
io.use((socket, next) => { sessionMiddleware(socket.request, {}, next); });
io.use((socket, next) => {
  const token = socket.handshake.auth?.token;
  if (token) {
    const user = getUserFromToken(token);
    if (user) { socket.request.session = socket.request.session||{}; socket.request.session.userId = user.id; }
  }
  next();
});

// ── Helpers ───────────────────────────────────────────────────────────────────
const requireAuth = (req, res, next) => {
  let user = null;
  const authHeader = req.headers['authorization'];
  if (authHeader?.startsWith('Bearer ')) user = getUserFromToken(authHeader.slice(7));
  if (!user && req.session.userId) user = db.prepare('SELECT * FROM users WHERE id=?').get(req.session.userId);
  if (!user) return res.status(401).json({ error: 'Non authentifié' });
  if (user.banned) {
    // Vérifier si le ban temporaire est expiré
    if (user.banned_until && new Date(user.banned_until) <= new Date()) {
      db.prepare("UPDATE users SET banned=0,ban_reason='',banned_until=NULL WHERE id=?").run(user.id);
      user.banned = 0;
    } else {
      return res.status(403).json({ error: 'Compte banni', reason: user.ban_reason });
    }
  }
  req.user = user;
  req.session.userId = user.id;
  next();
};
const requireAdmin = (req, res, next) => {
  if (req.user?.role !== 'admin') return res.status(403).json({ error: 'Accès refusé' });
  next();
};
const auditLog = (adminId, action, target='', detail='') =>
  db.prepare('INSERT INTO audit_log (admin_id,action,target,detail) VALUES (?,?,?,?)').run(adminId,action,target,detail);

const getReactions = (messageId, myUserId) =>
  db.prepare(`SELECT r.emoji,COUNT(*) as count,GROUP_CONCAT(u.display_name) as names,
    MAX(CASE WHEN r.user_id=? THEN 1 ELSE 0 END) as reacted
    FROM reactions r JOIN users u ON u.id=r.user_id WHERE r.message_id=?
    GROUP BY r.emoji ORDER BY count DESC`).all(myUserId, messageId);

// Nettoyage bans temporaires expirés
setInterval(() => {
  try {
    db.prepare("UPDATE users SET banned=0,ban_reason='',banned_until=NULL WHERE banned=1 AND banned_until IS NOT NULL AND banned_until<=datetime('now')").run();
  } catch(_){}
}, 30000);




// ── Web Push (via package web-push) ──────────────────────────────────────────
async function pushToUser(userId, title, body) {
  const subs = db.prepare('SELECT * FROM push_subscriptions WHERE user_id=?').all(userId);
  for (const sub of subs) {
    try {
      await webpush.sendNotification(
        { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } },
        JSON.stringify({
          title,
          body,
          icon: '/icon-192.png',
          badge: '/icon-72.png',
          tag: `msg-${userId}`,
          renotify: true,
          data: { url: '/' }
        })
      );
    } catch(e) {
      console.error('Push error:', e.statusCode, e.message);
      // Supprimer les subscriptions expirées
      if (e.statusCode === 404 || e.statusCode === 410) {
        db.prepare('DELETE FROM push_subscriptions WHERE id=?').run(sub.id);
      }
    }
  }
}

const connectedUsers = new Map();

// ── AUTH ──────────────────────────────────────────────────────────────────────
app.post('/api/register', async (req, res) => {
  const { login, display_name, password } = req.body;
  if (!login||!display_name||!password) return res.status(400).json({ error: 'Tous les champs sont requis' });
  if (login.length<3) return res.status(400).json({ error: 'Identifiant trop court (min 3)' });
  if (display_name.length<2) return res.status(400).json({ error: 'Pseudo trop court (min 2)' });
  if (password.length<6) return res.status(400).json({ error: 'Mot de passe trop court (min 6)' });
  if (/\s/.test(login)) return res.status(400).json({ error: "Pas d'espaces dans l'identifiant" });
  try {
    const hash = await bcrypt.hash(password, 12);
    const role = login === ADMIN_LOGIN ? 'admin' : 'user';
    const r = db.prepare('INSERT INTO users (login,display_name,password,role) VALUES (?,?,?,?)').run(login.trim(), display_name.trim(), hash, role);
    req.session.userId = r.lastInsertRowid;
    const token = createUserToken(r.lastInsertRowid);
    res.json({ success:true, token, user:{ id:r.lastInsertRowid, login:login.trim(), display_name:display_name.trim(), role } });
  } catch(e) {
    if (e.message?.includes('UNIQUE')&&e.message?.includes('login')) return res.status(409).json({ error:'Identifiant déjà pris' });
    if (e.message?.includes('UNIQUE')&&e.message?.includes('display_name')) return res.status(409).json({ error:'Pseudo déjà pris' });
    res.status(500).json({ error:'Erreur serveur' });
  }
});

app.post('/api/login', async (req, res) => {
  const { login, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE login=?').get(login?.trim());
  if (!user) return res.status(401).json({ error:'Identifiant ou mot de passe incorrect' });
  if (user.banned) {
    if (user.banned_until && new Date(user.banned_until) <= new Date()) {
      db.prepare("UPDATE users SET banned=0,ban_reason='',banned_until=NULL WHERE id=?").run(user.id);
    } else {
      return res.status(403).json({ error:'Compte banni', reason:user.ban_reason });
    }
  }
  if (!await bcrypt.compare(password, user.password)) return res.status(401).json({ error:'Identifiant ou mot de passe incorrect' });
  if (user.login===ADMIN_LOGIN) db.prepare("UPDATE users SET role='admin' WHERE id=?").run(user.id);
  req.session.userId = user.id;
  db.prepare('UPDATE users SET online=1 WHERE id=?').run(user.id);
  const token = createUserToken(user.id);
  res.json({ success:true, token, user:{ id:user.id, login:user.login, display_name:user.display_name, role:user.login===ADMIN_LOGIN?'admin':user.role } });
});

app.post('/api/logout', requireAuth, (req, res) => {
  const authHeader = req.headers['authorization'];
  if (authHeader?.startsWith('Bearer ')) db.prepare('DELETE FROM tokens WHERE token=?').run(authHeader.slice(7));
  db.prepare('UPDATE users SET online=0 WHERE id=?').run(req.session.userId);
  req.session.destroy(()=>{});
  res.json({ success:true });
});

app.get('/api/auth/verify', (req, res) => {
  const authHeader = req.headers['authorization'];
  if (!authHeader?.startsWith('Bearer ')) return res.status(401).json({ error:'Pas de token' });
  const user = getUserFromToken(authHeader.slice(7));
  if (!user) return res.status(401).json({ error:'Token invalide' });
  if (user.banned && (!user.banned_until || new Date(user.banned_until) > new Date())) return res.status(403).json({ error:'Banni' });
  res.json({ id:user.id, login:user.login, display_name:user.display_name, role:user.login===ADMIN_LOGIN?'admin':user.role });
});

app.get('/api/me', requireAuth, (req, res) => {
  res.json(db.prepare('SELECT id,login,display_name,bio,avatar,role,grade,created_at FROM users WHERE id=?').get(req.session.userId));
});

// ── PUSH ──────────────────────────────────────────────────────────────────────
app.get('/api/push/vapid-key', (req, res) => res.json({ publicKey: VAPID_PUBLIC }));

app.post('/api/push/subscribe', requireAuth, (req, res) => {
  const { endpoint, keys } = req.body;
  if (!endpoint||!keys?.p256dh||!keys?.auth) return res.status(400).json({ error:'Données manquantes' });
  try {
    db.prepare(`INSERT INTO push_subscriptions (user_id,endpoint,p256dh,auth) VALUES (?,?,?,?)
      ON CONFLICT(endpoint) DO UPDATE SET user_id=excluded.user_id,p256dh=excluded.p256dh,auth=excluded.auth`
    ).run(req.session.userId, endpoint, keys.p256dh, keys.auth);
    res.json({ success:true });
  } catch(e) { res.status(500).json({ error:e.message }); }
});

app.post('/api/push/unsubscribe', requireAuth, (req, res) => {
  const { endpoint } = req.body;
  if (endpoint) db.prepare('DELETE FROM push_subscriptions WHERE endpoint=? AND user_id=?').run(endpoint, req.session.userId);
  res.json({ success:true });
});

// ── USERS ─────────────────────────────────────────────────────────────────────

// Stats du profil utilisateur connecté
app.get('/api/users/stats', requireAuth, (req, res) => {
  const myId = req.session.userId;
  const messages = db.prepare('SELECT COUNT(*) as c FROM messages WHERE sender_id=? AND deleted=0').get(myId).c;
  const reactions = db.prepare('SELECT COUNT(*) as c FROM reactions WHERE user_id=?').get(myId).c;
  const user = db.prepare('SELECT created_at FROM users WHERE id=?').get(myId);
  const days = user ? Math.max(1, Math.floor((Date.now() - new Date(user.created_at).getTime()) / 86400000)) : 0;
  res.json({ messages, reactions, days });
});

// Modifier sa bio
app.put('/api/users/bio', requireAuth, (req, res) => {
  const { bio } = req.body;
  db.prepare('UPDATE users SET bio=? WHERE id=?').run((bio||'').trim().substring(0,100), req.session.userId);
  res.json({ success: true });
});

// Modifier son avatar (base64)
app.put('/api/users/avatar', requireAuth, (req, res) => {
  const { avatar } = req.body;
  if (!avatar) return res.status(400).json({ error: 'Avatar vide' });
  if (avatar.length > 800000) return res.status(400).json({ error: 'Image trop grande (max ~600Ko)' });
  db.prepare('UPDATE users SET avatar=? WHERE id=?').run(avatar, req.session.userId);
  io.emit('user:avatar_changed', { userId: req.session.userId, avatar });
  res.json({ success: true });
});

app.get('/api/users', requireAuth, (req, res) => {
  const users = db.prepare('SELECT id,display_name,bio,avatar,online,role,grade,banned,banned_until,created_at FROM users WHERE id!=? ORDER BY online DESC,display_name ASC').all(req.session.userId);
  res.json(users.map(u => {
    const unread = db.prepare('SELECT COUNT(*) as c FROM messages WHERE sender_id=? AND receiver_id=? AND read=0 AND deleted=0').get(u.id, req.session.userId);
    return { ...u, unread: unread.c };
  }));
});

app.put('/api/users/display-name', requireAuth, (req, res) => {
  const { display_name } = req.body;
  if (!display_name||display_name.trim().length<2) return res.status(400).json({ error:'Pseudo trop court' });
  if (display_name.trim().length>30) return res.status(400).json({ error:'Pseudo trop long (max 30)' });
  try {
    db.prepare('UPDATE users SET display_name=? WHERE id=?').run(display_name.trim(), req.session.userId);
    io.emit('user:name_changed', { userId:req.session.userId, display_name:display_name.trim() });
    res.json({ success:true, display_name:display_name.trim() });
  } catch(e) {
    if (e.message?.includes('UNIQUE')) return res.status(409).json({ error:'Pseudo déjà pris' });
    res.status(500).json({ error:'Erreur serveur' });
  }
});

// ── MESSAGES ──────────────────────────────────────────────────────────────────
app.get('/api/messages/:userId', requireAuth, (req, res) => {
  const otherId=parseInt(req.params.userId), myId=req.session.userId;
  db.prepare('UPDATE messages SET read=1 WHERE sender_id=? AND receiver_id=? AND read=0').run(otherId, myId);
  const msgs = db.prepare(`
    SELECT m.*,u.display_name as sender_name,
      r.content as reply_content,ru.display_name as reply_sender_name
    FROM messages m JOIN users u ON u.id=m.sender_id
    LEFT JOIN messages r ON r.id=m.reply_to
    LEFT JOIN users ru ON ru.id=r.sender_id
    WHERE m.deleted=0 AND ((m.sender_id=? AND m.receiver_id=?) OR (m.sender_id=? AND m.receiver_id=?))
    ORDER BY m.created_at ASC LIMIT 200`).all(myId,otherId,otherId,myId);
  res.json(msgs.map(m => ({ ...m, reactions:getReactions(m.id, myId) })));
});

app.delete('/api/messages/:id', requireAuth, (req, res) => {
  const msg = db.prepare('SELECT * FROM messages WHERE id=? AND deleted=0').get(parseInt(req.params.id));
  if (!msg) return res.status(404).json({ error:'Introuvable' });
  if (msg.sender_id !== req.session.userId) return res.status(403).json({ error:'Pas ton message' });
  db.prepare('UPDATE messages SET deleted=1 WHERE id=?').run(msg.id);
  [msg.sender_id, msg.receiver_id].forEach(uid => {
    const s = connectedUsers.get(uid);
    if (s) io.to(s).emit('message:deleted', { messageId:msg.id });
  });
  res.json({ success:true });
});

app.put('/api/messages/:id', requireAuth, (req, res) => {
  const { content } = req.body;
  if (!content?.trim()) return res.status(400).json({ error:'Contenu vide' });
  const msg = db.prepare('SELECT * FROM messages WHERE id=? AND deleted=0').get(parseInt(req.params.id));
  if (!msg) return res.status(404).json({ error:'Introuvable' });
  if (msg.sender_id !== req.session.userId) return res.status(403).json({ error:'Pas ton message' });
  db.prepare('UPDATE messages SET content=?,edited=1 WHERE id=?').run(content.trim(), msg.id);
  [msg.sender_id, msg.receiver_id].forEach(uid => {
    const s = connectedUsers.get(uid);
    if (s) io.to(s).emit('message:edited', { messageId:msg.id, content:content.trim() });
  });
  res.json({ success:true });
});

app.post('/api/messages/:id/react', requireAuth, (req, res) => {
  const msgId=parseInt(req.params.id), { emoji }=req.body, myId=req.session.userId;
  if (!emoji) return res.status(400).json({ error:'Emoji requis' });
  const msg = db.prepare('SELECT * FROM messages WHERE id=? AND deleted=0').get(msgId);
  if (!msg) return res.status(404).json({ error:'Introuvable' });
  if (msg.sender_id!==myId && msg.receiver_id!==myId) return res.status(403).json({ error:'Accès refusé' });
  const ex = db.prepare('SELECT id FROM reactions WHERE message_id=? AND user_id=? AND emoji=?').get(msgId,myId,emoji);
  if (ex) db.prepare('DELETE FROM reactions WHERE id=?').run(ex.id);
  else db.prepare('INSERT OR IGNORE INTO reactions (message_id,user_id,emoji) VALUES (?,?,?)').run(msgId,myId,emoji);
  [msg.sender_id, msg.receiver_id].forEach(uid => {
    const s = connectedUsers.get(uid);
    if (s) io.to(s).emit('reaction:update', { messageId:msgId, reactions:getReactions(msgId,uid) });
  });
  res.json({ success:true, reactions:getReactions(msgId,myId) });
});


// ── ROUTES MODÉRATEUR (accès limité) ─────────────────────────────────────────
const requireMod = (req, res, next) => {
  if (req.user?.role !== 'admin' && req.user?.role !== 'moderator')
    return res.status(403).json({ error: 'Accès modérateur requis' });
  next();
};

// Stats visibles aux modérateurs
app.get('/api/mod/stats', requireAuth, requireMod, (req, res) => {
  res.json({
    totalUsers:   db.prepare('SELECT COUNT(*) as c FROM users').get().c,
    onlineUsers:  db.prepare('SELECT COUNT(*) as c FROM users WHERE online=1').get().c,
    bannedUsers:  db.prepare('SELECT COUNT(*) as c FROM users WHERE banned=1').get().c,
    totalMessages:db.prepare('SELECT COUNT(*) as c FROM messages WHERE deleted=0').get().c,
  });
});

// Liste users pour modérateurs
app.get('/api/mod/users', requireAuth, requireMod, (req, res) => {
  res.json(db.prepare('SELECT id,display_name,role,grade,banned,ban_reason,banned_until,online,created_at FROM users ORDER BY online DESC,display_name ASC').all());
});

// Modérateur peut kicker
app.post('/api/mod/users/:id/kick', requireAuth, requireMod, (req, res) => {
  const tid=parseInt(req.params.id);
  const { reason }=req.body;
  const t=db.prepare('SELECT * FROM users WHERE id=?').get(tid);
  if (!t) return res.status(404).json({ error:'Introuvable' });
  if (t.role==='admin') return res.status(403).json({ error:"Impossible de kicker un admin" });
  const sock=connectedUsers.get(tid);
  if (sock) io.to(sock).emit('force:kick', { reason:reason||'Déconnecté par un modérateur.' });
  db.prepare('UPDATE users SET online=0 WHERE id=?').run(tid);
  auditLog(req.session.userId,'KICK',t.display_name,reason||'(par mod)');
  res.json({ success:true, wasOnline:!!sock });
});

// Modérateur peut ban temporaire (max 24h)
app.post('/api/mod/users/:id/ban', requireAuth, requireMod, (req, res) => {
  const tid=parseInt(req.params.id);
  const { reason, duration }=req.body;
  const dur=Math.min(parseInt(duration)||30, 1440); // max 24h pour un mod
  const t=db.prepare('SELECT * FROM users WHERE id=?').get(tid);
  if (!t) return res.status(404).json({ error:'Introuvable' });
  if (t.role==='admin'||t.role==='moderator') return res.status(403).json({ error:"Impossible de bannir un admin/mod" });
  const bannedUntil=new Date(Date.now()+dur*60*1000).toISOString();
  db.prepare("UPDATE users SET banned=1,ban_reason=?,banned_until=? WHERE id=?").run(reason||'Modération',bannedUntil,tid);
  const sock=connectedUsers.get(tid);
  if (sock) io.to(sock).emit('force:logout', { reason:`Banni temporairement (${dur}min) : ${reason||'Modération'}` });
  auditLog(req.session.userId,'BAN_TEMP',t.display_name,`${dur}min - ${reason||''}`);
  io.emit('admin:user_update', { userId:tid, banned:true });
  res.json({ success:true });
});

// Modérateur peut modifier un message
app.put('/api/mod/messages/:id', requireAuth, requireMod, (req, res) => {
  const { content } = req.body;
  if (!content?.trim()) return res.status(400).json({ error: 'Contenu vide' });
  const msg = db.prepare('SELECT * FROM messages WHERE id=?').get(parseInt(req.params.id));
  if (!msg) return res.status(404).json({ error: 'Introuvable' });
  db.prepare('UPDATE messages SET content=?,edited=1 WHERE id=?').run(content.trim(), msg.id);
  auditLog(req.session.userId, 'EDIT_MSG', `msg#${msg.id}`, content.trim().substring(0,60));
  [msg.sender_id, msg.receiver_id].forEach(uid => {
    const s = connectedUsers.get(uid);
    if (s) io.to(s).emit('message:edited', { messageId: msg.id, content: content.trim() });
  });
  res.json({ success: true });
});

// Modérateur peut supprimer un message
app.delete('/api/mod/messages/:id', requireAuth, requireMod, (req, res) => {
  const msg=db.prepare('SELECT * FROM messages WHERE id=?').get(parseInt(req.params.id));
  if (!msg) return res.status(404).json({ error:'Introuvable' });
  db.prepare('UPDATE messages SET deleted=1 WHERE id=?').run(msg.id);
  auditLog(req.session.userId,'DELETE_MSG',`msg#${msg.id}`,msg.content.substring(0,60));
  [msg.sender_id,msg.receiver_id].forEach(uid=>{
    const s=connectedUsers.get(uid);
    if (s) io.to(s).emit('message:deleted',{messageId:msg.id});
  });
  res.json({ success:true });
});

// ── ADMIN ─────────────────────────────────────────────────────────────────────
app.get('/api/admin/stats', requireAuth, requireAdmin, (req, res) => {
  res.json({
    totalUsers:    db.prepare('SELECT COUNT(*) as c FROM users').get().c,
    onlineUsers:   db.prepare('SELECT COUNT(*) as c FROM users WHERE online=1').get().c,
    bannedUsers:   db.prepare('SELECT COUNT(*) as c FROM users WHERE banned=1').get().c,
    totalMessages: db.prepare('SELECT COUNT(*) as c FROM messages WHERE deleted=0').get().c,
    todayMessages: db.prepare("SELECT COUNT(*) as c FROM messages WHERE date(created_at)=date('now') AND deleted=0").get().c,
    newUsers7d:    db.prepare("SELECT COUNT(*) as c FROM users WHERE created_at>=datetime('now','-7 days')").get().c,
  });
});

app.get('/api/admin/users', requireAuth, requireAdmin, (req, res) => {
  res.json(db.prepare('SELECT id,login,display_name,role,grade,banned,ban_reason,banned_until,online,created_at,(SELECT COUNT(*) FROM messages WHERE sender_id=users.id AND deleted=0) as msg_count FROM users ORDER BY created_at DESC').all());
});

app.put('/api/admin/users/:id/display-name', requireAuth, requireAdmin, (req, res) => {
  const tid=parseInt(req.params.id), {display_name}=req.body;
  if (!display_name?.trim()) return res.status(400).json({ error:'Pseudo vide' });
  const t = db.prepare('SELECT * FROM users WHERE id=?').get(tid);
  if (!t) return res.status(404).json({ error:'Introuvable' });
  try {
    db.prepare('UPDATE users SET display_name=? WHERE id=?').run(display_name.trim(), tid);
    auditLog(req.session.userId,'RENAME',t.display_name,`→ ${display_name.trim()}`);
    io.emit('user:name_changed', { userId:tid, display_name:display_name.trim() });
    res.json({ success:true });
  } catch(e) {
    if (e.message?.includes('UNIQUE')) return res.status(409).json({ error:'Pseudo déjà pris' });
    res.status(500).json({ error:'Erreur serveur' });
  }
});

app.post('/api/admin/users/:id/ban', requireAuth, requireAdmin, (req, res) => {
  const tid=parseInt(req.params.id), { reason, duration }=req.body;
  const t = db.prepare('SELECT * FROM users WHERE id=?').get(tid);
  if (!t) return res.status(404).json({ error:'Introuvable' });
  if (t.login===ADMIN_LOGIN) return res.status(403).json({ error:"Impossible de bannir l'admin" });
  const bannedUntil = duration&&parseInt(duration)>0
    ? new Date(Date.now()+parseInt(duration)*60*1000).toISOString() : null;
  db.prepare("UPDATE users SET banned=1,ban_reason=?,banned_until=? WHERE id=?").run(reason||'Violation des règles', bannedUntil, tid);
  const sock = connectedUsers.get(tid);
  const msg = bannedUntil ? `Banni temporairement (${duration}min) : ${reason||''}` : `Banni : ${reason||'Violation des règles'}`;
  if (sock) io.to(sock).emit('force:logout', { reason:msg });
  auditLog(req.session.userId, bannedUntil?'BAN_TEMP':'BAN', t.display_name, reason||'');
  io.emit('admin:user_update', { userId:tid, banned:true });
  res.json({ success:true });
});

app.post('/api/admin/users/:id/unban', requireAuth, requireAdmin, (req, res) => {
  const tid=parseInt(req.params.id);
  const t = db.prepare('SELECT * FROM users WHERE id=?').get(tid);
  if (!t) return res.status(404).json({ error:'Introuvable' });
  db.prepare("UPDATE users SET banned=0,ban_reason='',banned_until=NULL WHERE id=?").run(tid);
  auditLog(req.session.userId,'UNBAN',t.display_name,'');
  io.emit('admin:user_update', { userId:tid, banned:false });
  res.json({ success:true });
});

// Changer le rôle d'un utilisateur (admin/user)
app.post('/api/admin/users/:id/role', requireAuth, requireAdmin, (req, res) => {
  const tid = parseInt(req.params.id);
  const { role } = req.body;
  if (!['admin','moderator','user'].includes(role)) return res.status(400).json({ error:'Rôle invalide' });
  const t = db.prepare('SELECT * FROM users WHERE id=?').get(tid);
  if (!t) return res.status(404).json({ error:'Introuvable' });
  if (t.login === ADMIN_LOGIN) return res.status(403).json({ error:"Impossible de modifier le rôle du super admin" });
  db.prepare('UPDATE users SET role=? WHERE id=?').run(role, tid);
  auditLog(req.session.userId, role==='admin'?'PROMOTE':'DEMOTE', t.display_name, `→ ${role}`);
  io.emit('user:role_changed', { userId: tid, role });
  res.json({ success: true });
});

// Changer le grade affiché d'un utilisateur
app.put('/api/admin/users/:id/grade', requireAuth, requireAdmin, (req, res) => {
  const tid = parseInt(req.params.id);
  const { grade } = req.body;
  const t = db.prepare('SELECT * FROM users WHERE id=?').get(tid);
  if (!t) return res.status(404).json({ error:'Introuvable' });
  db.prepare('UPDATE users SET grade=? WHERE id=?').run(grade?.trim()||null, tid);
  auditLog(req.session.userId, 'SET_GRADE', t.display_name, grade||'(supprimé)');
  io.emit('user:grade_changed', { userId: tid, grade: grade?.trim()||null });
  res.json({ success: true });
});

app.post('/api/admin/users/:id/kick', requireAuth, requireAdmin, (req, res) => {
  const tid=parseInt(req.params.id), { reason }=req.body;
  const t = db.prepare('SELECT * FROM users WHERE id=?').get(tid);
  if (!t) return res.status(404).json({ error:'Introuvable' });
  if (t.login===ADMIN_LOGIN) return res.status(403).json({ error:"Impossible de kicker l'admin" });
  const sock = connectedUsers.get(tid);
  if (sock) io.to(sock).emit('force:kick', { reason:reason||'Déconnecté par un administrateur.' });
  db.prepare('UPDATE users SET online=0 WHERE id=?').run(tid);
  auditLog(req.session.userId,'KICK',t.display_name,reason||'');
  res.json({ success:true, wasOnline:!!sock });
});

app.delete('/api/admin/users/:id', requireAuth, requireAdmin, (req, res) => {
  const tid=parseInt(req.params.id);
  const t = db.prepare('SELECT * FROM users WHERE id=?').get(tid);
  if (!t) return res.status(404).json({ error:'Introuvable' });
  if (t.login===ADMIN_LOGIN) return res.status(403).json({ error:"Impossible de supprimer l'admin" });
  const sock = connectedUsers.get(tid);
  if (sock) io.to(sock).emit('force:logout', { reason:'Compte supprimé par un administrateur.' });
  db.prepare('DELETE FROM reactions WHERE user_id=?').run(tid);
  db.prepare('DELETE FROM messages WHERE sender_id=? OR receiver_id=?').run(tid,tid);
  db.prepare('DELETE FROM push_subscriptions WHERE user_id=?').run(tid);
  db.prepare('DELETE FROM users WHERE id=?').run(tid);
  auditLog(req.session.userId,'DELETE_USER',t.display_name,'');
  io.emit('admin:user_deleted', { userId:tid });
  res.json({ success:true });
});

app.post('/api/admin/users/:id/reset-password', requireAuth, requireAdmin, async (req, res) => {
  const tid=parseInt(req.params.id), { newPassword }=req.body;
  if (!newPassword||newPassword.length<6) return res.status(400).json({ error:'Mot de passe trop court' });
  const t = db.prepare('SELECT * FROM users WHERE id=?').get(tid);
  if (!t) return res.status(404).json({ error:'Introuvable' });
  db.prepare('UPDATE users SET password=? WHERE id=?').run(await bcrypt.hash(newPassword,12), tid);
  auditLog(req.session.userId,'RESET_PASSWORD',t.display_name,'');
  res.json({ success:true });
});

app.get('/api/admin/conversations/:id1/:id2', requireAuth, requireAdmin, (req, res) => {
  const id1=parseInt(req.params.id1), id2=parseInt(req.params.id2);
  res.json(db.prepare(`SELECT m.*,u.display_name as sender_name FROM messages m JOIN users u ON u.id=m.sender_id WHERE (m.sender_id=? AND m.receiver_id=?) OR (m.sender_id=? AND m.receiver_id=?) ORDER BY m.created_at ASC LIMIT 500`).all(id1,id2,id2,id1));
});

app.delete('/api/admin/messages/:id', requireAuth, requireAdmin, (req, res) => {
  const msg = db.prepare('SELECT * FROM messages WHERE id=?').get(parseInt(req.params.id));
  if (!msg) return res.status(404).json({ error:'Introuvable' });
  db.prepare('UPDATE messages SET deleted=1 WHERE id=?').run(msg.id);
  auditLog(req.session.userId,'DELETE_MSG',`msg#${msg.id}`,msg.content.substring(0,60));
  [msg.sender_id,msg.receiver_id].forEach(uid => {
    const s=connectedUsers.get(uid);
    if (s) io.to(s).emit('message:deleted',{messageId:msg.id});
  });
  res.json({ success:true });
});

app.put('/api/admin/messages/:id', requireAuth, requireAdmin, (req, res) => {
  const { content }=req.body;
  if (!content?.trim()) return res.status(400).json({ error:'Contenu vide' });
  const msg = db.prepare('SELECT * FROM messages WHERE id=?').get(parseInt(req.params.id));
  if (!msg) return res.status(404).json({ error:'Introuvable' });
  db.prepare('UPDATE messages SET content=?,edited=1 WHERE id=?').run(content.trim(), msg.id);
  auditLog(req.session.userId,'EDIT_MSG',`msg#${msg.id}`,content.trim().substring(0,60));
  [msg.sender_id,msg.receiver_id].forEach(uid => {
    const s=connectedUsers.get(uid);
    if (s) io.to(s).emit('message:edited',{messageId:msg.id,content:content.trim()});
  });
  res.json({ success:true });
});

app.post('/api/admin/announce', requireAuth, requireAdmin, (req, res) => {
  const { message }=req.body;
  if (!message?.trim()) return res.status(400).json({ error:'Vide' });
  const admin = db.prepare('SELECT display_name FROM users WHERE id=?').get(req.session.userId);
  auditLog(req.session.userId,'ANNOUNCE','ALL',message);
  io.emit('admin:announce', { message:message.trim(), from:admin.display_name });
  res.json({ success:true });
});

app.get('/api/admin/audit', requireAuth, requireAdmin, (req, res) => {
  res.json(db.prepare('SELECT a.*,u.display_name as admin_name FROM audit_log a JOIN users u ON u.id=a.admin_id ORDER BY a.created_at DESC LIMIT 200').all());
});

// ── SOCKET ────────────────────────────────────────────────────────────────────

io.on('connection', (socket) => {
  const sess = socket.request.session;
  if (!sess?.userId) return socket.disconnect();
  const userId = sess.userId;
  const user = db.prepare('SELECT * FROM users WHERE id=?').get(userId);
  if (!user||user.banned) return socket.disconnect();

  connectedUsers.set(userId, socket.id);
  db.prepare('UPDATE users SET online=1 WHERE id=?').run(userId);
  io.emit('user:status', { userId, online:true });

  socket.on('message:send', ({ receiverId, content, replyTo }) => {
    if (!content?.trim()) return;
    const sender = db.prepare('SELECT * FROM users WHERE id=?').get(userId);
    if (!sender||sender.banned) return;
    const replyId = replyTo ? parseInt(replyTo) : null;
    const msg = db.prepare('INSERT INTO messages (sender_id,receiver_id,content,reply_to) VALUES (?,?,?,?)').run(userId, receiverId, content.trim(), replyId);
    const full = db.prepare(`SELECT m.*,u.display_name as sender_name,r.content as reply_content,ru.display_name as reply_sender_name FROM messages m JOIN users u ON u.id=m.sender_id LEFT JOIN messages r ON r.id=m.reply_to LEFT JOIN users ru ON ru.id=r.sender_id WHERE m.id=?`).get(msg.lastInsertRowid);
    const fw = { ...full, reactions:[] };
    socket.emit('message:new', fw);
    const rSock = connectedUsers.get(receiverId);
    if (rSock) {
      io.to(rSock).emit('message:new', fw);
      io.to(rSock).emit('message:notify', { from:sender.display_name, fromId:userId });
    }
    // Push notification si destinataire hors ligne
    if (!rSock) {
      pushToUser(receiverId, sender.display_name, content.trim().substring(0,100)).catch(()=>{});
    }
  });

  socket.on('disconnect', () => {
    connectedUsers.delete(userId);
    db.prepare('UPDATE users SET online=0 WHERE id=?').run(userId);
    io.emit('user:status', { userId, online:false });
  });
});

// ── DÉMARRAGE ─────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`✅  Backend sur http://0.0.0.0:${PORT}`);
  console.log(`🌐  Public : http://86.192.161.55:${PORT}`);
  console.log(`👑  Admin  : ${ADMIN_LOGIN}`);
  console.log(`🔒  CORS   : ${ALLOWED_ORIGINS.join(', ')}`);
  console.log(`🔔  VAPID  : ${VAPID_PUBLIC.substring(0,20)}...`);
});
